Virus Boom 2024 pc
WARNING
Virus created on notepad, this is not malware
Credits for SM3RTbEVbl2289 and LENOVOG710 for create.
How to start virus?
open the BOOMPC.bat